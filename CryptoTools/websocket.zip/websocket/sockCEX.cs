﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Net.WebSockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TradeBot.websocket
{
    class sockCEX
    {
        ClientWebSocket ws = null;
        string BaseUrl = "wss://ws.cex.io/ws/";
        private const int BufferSize = 4096;
        private const int BufferAmplifier = 20;
        byte[] buffer;
        Uri uri;

        public sockCEX()
        {
            //createAuthRequest("dmr8vjWhaODCmystaEnos8wZV54","DNADDxOpg27biH3bmNcP0PvFnug")
            uri = new Uri(BaseUrl);
            ws = new ClientWebSocket();
            Connect();
        }

        public async void Connect()
        {
            if (ws.State != WebSocketState.Open && ws.State != WebSocketState.Connecting)
            {
                await ws.ConnectAsync(uri, CancellationToken.None);
            }

            var request = Encoding.UTF8.GetBytes(Auth());

            await
                ws.SendAsync(new ArraySegment<byte>(request), WebSocketMessageType.Text, true,
                    CancellationToken.None);

            await Receive();
        }

        private async Task Receive()
        {
            var temporaryBuffer = new byte[BufferSize];
            buffer = new byte[BufferSize * BufferAmplifier];
            var offset = 0;

            while (ws.State == WebSocketState.Open)
            {
                WebSocketReceiveResult response;

                do
                {
                    response =
                        await ws.ReceiveAsync(new ArraySegment<byte>(temporaryBuffer), CancellationToken.None);
                    temporaryBuffer.CopyTo(buffer, offset);
                    offset += response.Count;
                    temporaryBuffer = new byte[BufferSize];
                } while (!response.EndOfMessage);

                if (response.MessageType == WebSocketMessageType.Close)
                {
                    await
                        ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Close response received",
                            CancellationToken.None);
                }
                else
                {
                    var result = Encoding.UTF8.GetString(buffer);
/*                    var responseObject = JsonConvert.DeserializeObject<Response>(result,
                        _requestParameters.ResponseDataType);

                    _requestParameters.FireEvent(this,
                        new SocketEventArgs { Response = responseObject, Activity = responseObject.Data.Activity });*/
                    buffer = new byte[BufferSize * BufferAmplifier];
                    offset = 0;
                }
            }
        }

        public void Dispose()
        {
            ws.Dispose();
        }

        private string Auth()
        {
            string apiKey = "dmr8vjWhaODCmystaEnos8wZV54";
            string apiSecret = "DNADDxOpg27biH3bmNcP0PvFnug";

            Int32 unixTimestamp = (Int32)(DateTime.UtcNow.Subtract(new DateTime(1970, 1, 1))).TotalSeconds;
            HMACSHA256 hmac = new HMACSHA256(Encoding.ASCII.GetBytes(apiSecret));
            byte[] sha256_arr = Encoding.ASCII.GetBytes(unixTimestamp.ToString() + apiKey);
            string signature = "";
            sha256_arr = hmac.ComputeHash(sha256_arr);
            for (int i = 0; i < sha256_arr.Length; i++)
            {
                signature = signature + sha256_arr[i].ToString("X2");
            }

            dynamic jsonObject = new JObject();
            jsonObject.e = "auth";
            jsonObject.auth = new JObject();
            jsonObject.auth.key = apiKey;
            jsonObject.auth.signature = signature;
            jsonObject.auth.timestamp = unixTimestamp;
            string msg = JsonConvert.SerializeObject(jsonObject);

            return msg;

            /*var segment = new ArraySegment<byte>(Encoding.ASCII.GetBytes(msg));
            ws.SendAsync(segment, WebSocketMessageType.Text, false, CancellationToken.None);
            ArraySegment<byte> rslt = new ArraySegment<byte>();
            WebSocketReceiveResult wsrslt = ws.ReceiveAsync(rslt, CancellationToken.None);*/

        }

    }
}
